# cyk_parser.py
import time
from collections import defaultdict

class CYKParser:
    def __init__(self, grammar):
        self.grammar = grammar
        self.reverse_grammar = self._build_reverse_grammar()
    
    def _build_reverse_grammar(self):
        """Construye un mapeo de producciones a no-terminales"""
        reverse = defaultdict(list)
        for non_terminal, productions in self.grammar.items():
            for production in productions:
                if len(production) == 1:  # Producción terminal
                    reverse[production[0]].append(non_terminal)
                else:  # Producción binaria
                    reverse[tuple(production)].append(non_terminal)
        return reverse
    
    def parse(self, tokens):
        """Algoritmo CYK para gramáticas en forma normal de Chomsky"""
        n = len(tokens)
        if n == 0:
            return False
            
        # Inicializar tabla CYK
        table = [[set() for _ in range(n)] for _ in range(n)]
        
        # Paso 1: Llenar diagonal (producciones terminales)
        for i in range(n):
            token = tokens[i]
            if token in self.reverse_grammar:
                table[i][i] = set(self.reverse_grammar[token])
        
        # Paso 2: Llenar el resto de la tabla
        for length in range(2, n + 1):  # Longitud de la subcadena
            for i in range(n - length + 1):
                j = i + length - 1
                for k in range(i, j):  # Punto de división
                    # Verificar todas las combinaciones posibles
                    for B in table[i][k]:
                        for C in table[k + 1][j]:
                            production = (B, C)
                            if production in self.reverse_grammar:
                                table[i][j].update(self.reverse_grammar[production])
        
        # Verificar si el símbolo inicial está en la celda superior derecha
        return 'E' in table[0][n - 1]
    
    def benchmark(self, test_cases, iterations=1000):
        """Ejecuta pruebas de rendimiento"""
        times = []
        
        for tokens in test_cases:
            start_time = time.perf_counter()
            for _ in range(iterations):
                self.parse(tokens)
            end_time = time.perf_counter()
            times.append((end_time - start_time) / iterations)
        
        return times