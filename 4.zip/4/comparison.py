# comparison.py
import time
import matplotlib.pyplot as plt
from cyk_parser import CYKParser
from predictive_parser import PredictiveParser

# Gramática para CYK (en Forma Normal de Chomsky)
cyk_grammar = {
    'E': [['T', "E'"], ['T']],
    "E'": [['+', 'T', "E'"], ['+', 'T']],
    'T': [['F', "T'"], ['F']],
    "T'": [['*', 'F', "T'"], ['*', 'F']],
    'F': [['(', 'E', ')'], ['id']]
}

# Casos de prueba
test_cases = [
    ['id'],
    ['id', '+', 'id'],
    ['id', '*', 'id'], 
    ['id', '+', 'id', '*', 'id'],
    ['(', 'id', '+', 'id', ')', '*', 'id'],
    ['id', '*', '(', 'id', '+', 'id', ')', '*', 'id'],
    ['id', '+', 'id', '+', 'id', '*', 'id', '+', 'id']
]

test_case_names = [
    'id', 'id+id', 'id*id', 'id+id*id', 
    '(id+id)*id', 'id*(id+id)*id', 'id+id+id*id+id'
]

def run_comparison():
    # Crear parsers
    cyk_parser = CYKParser(cyk_grammar)
    
    print("=== COMPARACIÓN DE PARSERS ===")
    print("Gramática: E → E + T | T, T → T * F | F, F → (E) | id")
    print("=" * 50)
    
    # Probar corrección
    print("Verificación de corrección:")
    for i, tokens in enumerate(test_cases):
        cyk_result = cyk_parser.parse(tokens)
        predictive_result = PredictiveParser(tokens).parse()
        
        print(f"{test_case_names[i]:<20} | CYK: {cyk_result:^6} | Predictivo: {predictive_result:^6}")
    
    print("\n" + "=" * 50)
    
    # Benchmarking
    iterations = 1000
    print(f"Benchmarking ({iterations} iteraciones por caso):")
    
    cyk_times = cyk_parser.benchmark(test_cases, iterations)
    predictive_times = PredictiveParser.benchmark(test_cases, iterations)
    
    print(f"{'Caso de prueba':<20} | {'CYK (ms)':<10} | {'Predictivo (ms)':<12} | {'Ratio':<8}")
    print("-" * 65)
    
    for i in range(len(test_cases)):
        cyk_ms = cyk_times[i] * 1000
        predictive_ms = predictive_times[i] * 1000
        ratio = cyk_ms / predictive_ms if predictive_ms > 0 else float('inf')
        
        print(f"{test_case_names[i]:<20} | {cyk_ms:>8.4f} | {predictive_ms:>11.4f} | {ratio:>6.2f}x")
    
    # Gráfico comparativo
    try:
        plt.figure(figsize=(12, 6))
        
        x = range(len(test_cases))
        width = 0.35
        
        plt.bar([i - width/2 for i in x], [t * 1000 for t in cyk_times], 
                width, label='CYK', alpha=0.7)
        plt.bar([i + width/2 for i in x], [t * 1000 for t in predictive_times], 
                width, label='Predictivo', alpha=0.7)
        
        plt.xlabel('Caso de prueba')
        plt.ylabel('Tiempo (milisegundos)')
        plt.title('Comparación de Rendimiento: CYK vs Parser Predictivo')
        plt.xticks(x, test_case_names, rotation=45)
        plt.legend()
        plt.tight_layout()
        plt.savefig('comparacion_parsers.png', dpi=300, bbox_inches='tight')
        plt.show()
    except ImportError:
        print("\nMatplotlib no está instalado. Omitiendo gráfico...")
    
    # Análisis estadístico
    print("\n" + "=" * 50)
    print("ANÁLISIS ESTADÍSTICO:")
    print(f"Tiempo promedio CYK: {sum(cyk_times) * 1000 / len(cyk_times):.4f} ms")
    print(f"Tiempo promedio Predictivo: {sum(predictive_times) * 1000 / len(predictive_times):.4f} ms")
    print(f"Speedup promedio: {sum(cyk_times) / sum(predictive_times):.2f}x")

if __name__ == "__main__":
    run_comparison()