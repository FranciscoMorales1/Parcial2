# predictive_parser.py
import time

class PredictiveParser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.current = 0
        self.length = len(tokens)
    
    def match(self, expected):
        if self.current < self.length and self.tokens[self.current] == expected:
            self.current += 1
            return True
        return False
    
    def parse_E(self):
        # E → T E'
        if not self.parse_T():
            return False
        return self.parse_E_prime()
    
    def parse_E_prime(self):
        # E' → + T E' | ε
        if self.match('+'):
            if not self.parse_T():
                return False
            return self.parse_E_prime()
        return True  # epsilon
    
    def parse_T(self):
        # T → F T'
        if not self.parse_F():
            return False
        return self.parse_T_prime()
    
    def parse_T_prime(self):
        # T' → * F T' | ε
        if self.match('*'):
            if not self.parse_F():
                return False
            return self.parse_T_prime()
        return True  # epsilon
    
    def parse_F(self):
        # F → ( E ) | id
        if self.match('('):
            if not self.parse_E():
                return False
            if not self.match(')'):
                return False
            return True
        elif self.match('id'):
            return True
        return False
    
    def parse(self):
        self.current = 0
        result = self.parse_E() and self.current == self.length
        return result
    
    @classmethod
    def benchmark(cls, test_cases, iterations=1000):
        """Ejecuta pruebas de rendimiento"""
        times = []
        
        for tokens in test_cases:
            start_time = time.perf_counter()
            for _ in range(iterations):
                parser = cls(tokens)
                parser.parse()
            end_time = time.perf_counter()
            times.append((end_time - start_time) / iterations)
        
        return times