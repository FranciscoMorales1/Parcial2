// Generated from gramatica.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link gramaticaParser}.
 */
public interface gramaticaListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(gramaticaParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(gramaticaParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterStmt(gramaticaParser.StmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitStmt(gramaticaParser.StmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#createStmt}.
	 * @param ctx the parse tree
	 */
	void enterCreateStmt(gramaticaParser.CreateStmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#createStmt}.
	 * @param ctx the parse tree
	 */
	void exitCreateStmt(gramaticaParser.CreateStmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#columnList}.
	 * @param ctx the parse tree
	 */
	void enterColumnList(gramaticaParser.ColumnListContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#columnList}.
	 * @param ctx the parse tree
	 */
	void exitColumnList(gramaticaParser.ColumnListContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#insertStmt}.
	 * @param ctx the parse tree
	 */
	void enterInsertStmt(gramaticaParser.InsertStmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#insertStmt}.
	 * @param ctx the parse tree
	 */
	void exitInsertStmt(gramaticaParser.InsertStmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#valueList}.
	 * @param ctx the parse tree
	 */
	void enterValueList(gramaticaParser.ValueListContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#valueList}.
	 * @param ctx the parse tree
	 */
	void exitValueList(gramaticaParser.ValueListContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#selectStmt}.
	 * @param ctx the parse tree
	 */
	void enterSelectStmt(gramaticaParser.SelectStmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#selectStmt}.
	 * @param ctx the parse tree
	 */
	void exitSelectStmt(gramaticaParser.SelectStmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#columnSelector}.
	 * @param ctx the parse tree
	 */
	void enterColumnSelector(gramaticaParser.ColumnSelectorContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#columnSelector}.
	 * @param ctx the parse tree
	 */
	void exitColumnSelector(gramaticaParser.ColumnSelectorContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#whereClause}.
	 * @param ctx the parse tree
	 */
	void enterWhereClause(gramaticaParser.WhereClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#whereClause}.
	 * @param ctx the parse tree
	 */
	void exitWhereClause(gramaticaParser.WhereClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#condition}.
	 * @param ctx the parse tree
	 */
	void enterCondition(gramaticaParser.ConditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#condition}.
	 * @param ctx the parse tree
	 */
	void exitCondition(gramaticaParser.ConditionContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#compOp}.
	 * @param ctx the parse tree
	 */
	void enterCompOp(gramaticaParser.CompOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#compOp}.
	 * @param ctx the parse tree
	 */
	void exitCompOp(gramaticaParser.CompOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#updateStmt}.
	 * @param ctx the parse tree
	 */
	void enterUpdateStmt(gramaticaParser.UpdateStmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#updateStmt}.
	 * @param ctx the parse tree
	 */
	void exitUpdateStmt(gramaticaParser.UpdateStmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#assignmentList}.
	 * @param ctx the parse tree
	 */
	void enterAssignmentList(gramaticaParser.AssignmentListContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#assignmentList}.
	 * @param ctx the parse tree
	 */
	void exitAssignmentList(gramaticaParser.AssignmentListContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#assignment}.
	 * @param ctx the parse tree
	 */
	void enterAssignment(gramaticaParser.AssignmentContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#assignment}.
	 * @param ctx the parse tree
	 */
	void exitAssignment(gramaticaParser.AssignmentContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#deleteStmt}.
	 * @param ctx the parse tree
	 */
	void enterDeleteStmt(gramaticaParser.DeleteStmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#deleteStmt}.
	 * @param ctx the parse tree
	 */
	void exitDeleteStmt(gramaticaParser.DeleteStmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link gramaticaParser#value}.
	 * @param ctx the parse tree
	 */
	void enterValue(gramaticaParser.ValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link gramaticaParser#value}.
	 * @param ctx the parse tree
	 */
	void exitValue(gramaticaParser.ValueContext ctx);
}