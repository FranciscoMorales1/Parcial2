import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.gui.TreeViewer;
import javax.swing.*;
import java.io.IOException;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== ANALIZADOR CRUD (ANTLR) ===");
        System.out.println("Escribe comandos SQL (CREATE, INSERT, SELECT, UPDATE, DELETE).");
        System.out.println("Escribe EXIT o SALIR para terminar.\n");

        while (true) {
            System.out.print("SQL> ");
            String inputLine = scanner.nextLine().trim();

            // Comando para salir
            if (inputLine.equalsIgnoreCase("EXIT") || inputLine.equalsIgnoreCase("SALIR")) {
                System.out.println("\nFinalizando el analizador. Hasta luego!");
                break;
            }

            // Ignorar lineas vacias
            if (inputLine.isEmpty()) continue;

            try {
                // Crear lexer y parser
                CharStream input = CharStreams.fromString(inputLine);
                gramaticaLexer lexer = new gramaticaLexer(input);
                CommonTokenStream tokens = new CommonTokenStream(lexer);
                gramaticaParser parser = new gramaticaParser(tokens);

                // Analizar la regla inicial
                ParseTree tree = parser.program();

                // Mostrar el arbol en consola
                System.out.println("\nARBOL SINTACTICO:");
                System.out.println(tree.toStringTree(parser));

                // Mostrar el arbol graficamente
                JFrame frame = new JFrame("Arbol Sintactico - ANTLR CRUD");
                JPanel panel = new JPanel();
                TreeViewer viewer = new TreeViewer(Arrays.asList(parser.getRuleNames()), tree);
                viewer.setScale(1.3);
                panel.add(viewer);
                frame.add(panel);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(800, 600);
                frame.setVisible(true);

            } catch (Exception e) {
                System.err.println("Error al analizar la entrada: " + e.getMessage());
            }
        }

        scanner.close();
    }
}
