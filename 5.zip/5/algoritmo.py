def match(self, expected_token):
    """
    Algoritmo de emparejamiento para parser descendente recursivo.
    
    Verifica si el token actual coincide con el token esperado.
    Si coincide, consume el token y avanza a la siguiente posición.
    
    Args:
        expected_token: El token que se espera encontrar
    
    Returns:
        bool: True si hay coincidencia, False si no
    """
    # Verificar si hay tokens disponibles
    if self.current >= len(self.tokens):
        return False  # Fin de entrada inesperado
    
    # Verificar coincidencia
    if self.tokens[self.current] == expected_token:
        self.current += 1  # Consumir token y avanzar
        return True
    else:
        return False  # Token inesperado