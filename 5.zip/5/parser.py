class PredictiveParser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.current = 0  # Posición actual en la lista de tokens
    
    def match(self, expected_token):
        """Algoritmo de emparejamiento"""
        if self.current < len(self.tokens) and self.tokens[self.current] == expected_token:
            self.current += 1
            return True
        return False
    
    def parse_E(self):
        """E → T E'"""
        return self.parse_T() and self.parse_E_prime()
    
    def parse_E_prime(self):
        """E' → + T E' | ε"""
        if self.match('+'):
            return self.parse_T() and self.parse_E_prime()
        return True  # ε
    
    def parse_T(self):
        """T → F T'"""
        return self.parse_F() and self.parse_T_prime()
    
    def parse_T_prime(self):
        """T' → * F T' | ε"""
        if self.match('*'):
            return self.parse_F() and self.parse_T_prime()
        return True  # ε
    
    def parse_F(self):
        """F → ( E ) | id"""
        if self.match('('):
            return self.parse_E() and self.match(')')
        else:
            return self.match('id')
    
    def parse(self):
        """Método principal de análisis"""
        self.current = 0
        result = self.parse_E() and self.current == len(self.tokens)
        return result

def tokenize_expression(expr):
    """Convierte una expresión en lista de tokens"""
    tokens = []
    i = 0
    while i < len(expr):
        if expr[i].isspace():
            i += 1
            continue
        if expr[i:i+2] == "id":
            tokens.append('id')
            i += 2
        elif expr[i] in ['+', '*', '(', ')']:
            tokens.append(expr[i])
            i += 1
        else:
            raise ValueError(f"Carácter inválido en posición {i}: '{expr[i]}'")
    return tokens

# Programa principal con entrada de usuario
if __name__ == "__main__":
    print("=== Parser Predictivo con Algoritmo de Emparejamiento ===")
    print("Gramática: E → E + T | T, T → T * F | F, F → (E) | id")
    print("Solo se acepta el literal 'id' como operando.")
    print("ENTER vacío para salir.")
    print("--------------------------------------------")
    
    while True:
        try:
            expr = input("expr> ").strip()
        except EOFError:
            break
            
        if not expr:
            break
            
        try:
            tokens = tokenize_expression(expr)
            parser = PredictiveParser(tokens)
            result = parser.parse()
            print("ACEPTA" if result else "RECHAZA")
        except ValueError as e:
            print(f"ERROR: {e}")