# parser_asc.py
# Analizador sintáctico ascendente (shift–reduce)
# Gramática:
#   E → E + T | T
#   T → T * F | F
#   F → (E) | id

TOK_ID   = 'id'
TOK_PLUS = '+'
TOK_MUL  = '*'
TOK_LP   = '('
TOK_RP   = ')'
TOK_EOF  = '$'

def tokenize(src: str):
    tokens = []
    i = 0
    while i < len(src):
        c = src[i]
        if c.isspace():
            i += 1
            continue
        if src[i:i+2] == "id":
            tokens.append(TOK_ID)
            i += 2
        elif c in (TOK_PLUS, TOK_MUL, TOK_LP, TOK_RP):
            tokens.append(c)
            i += 1
        else:
            raise ValueError(f"Token inválido en posición {i}: '{c}'")
    tokens.append(TOK_EOF)
    return tokens

def try_reduce(stack, lookahead):
    """Aplica reducciones controladas por lookahead."""
    # F → (E)
    if len(stack) >= 3 and stack[-3] == TOK_LP and stack[-2] == 'E' and stack[-1] == TOK_RP:
        stack[-3:] = ['F']
        return True
    
    # F → id
    if len(stack) >= 1 and stack[-1] == TOK_ID:
        stack[-1:] = ['F']
        return True
    
    # T → T * F
    if len(stack) >= 3 and stack[-3] == 'T' and stack[-2] == TOK_MUL and stack[-1] == 'F':
        stack[-3:] = ['T']
        return True
    
    # T → F (reducción unitaria)
    if len(stack) >= 1 and stack[-1] == 'F':
        # Siempre podemos reducir F a T
        stack[-1:] = ['T']
        return True
    
    # E → E + T
    if len(stack) >= 3 and stack[-3] == 'E' and stack[-2] == TOK_PLUS and stack[-1] == 'T':
        stack[-3:] = ['E']
        return True
    
    # E → T (reducción unitaria)
    if len(stack) >= 1 and stack[-1] == 'T':
        # Solo reducir T→E si el lookahead no es * (para respetar precedencia)
        # Pero permitimos + para que E + T funcione
        if lookahead != TOK_MUL:
            stack[-1:] = ['E']
            return True
        return False
    
    return False

def parse_expression(expr: str, debug=False):
    try:
        tokens = tokenize(expr)
    except ValueError as e:
        print(e)
        return False

    stack = []
    i = 0

    if debug:
        print(f"TOKENS: {tokens}")

    while True:
        lookahead = tokens[i]
        
        # Reducir mientras sea posible
        reduced = True
        while reduced:
            reduced = try_reduce(stack, lookahead)
            if debug and reduced:
                print(f"REDUCE -> {stack}")

        if lookahead == TOK_EOF:
            # Últimas reducciones
            while try_reduce(stack, TOK_EOF):
                if debug:
                    print(f"REDUCE(FINAL) -> {stack}")
            break

        # SHIFT
        stack.append(lookahead)
        if debug:
            print(f"SHIFT {lookahead} -> {stack}")
        i += 1

    return stack == ['E']

if __name__ == "__main__":
    print("=== Analizador Ascendente (Shift–Reduce) ===")
    print("Gramática: E→E+T|T, T→T*F|F, F→(E)|id")
    print("Solo se acepta el literal 'id' como operando.")
    print("ENTER vacío para salir.")
    print("--------------------------------------------")

    while True:
        try:
            line = input("expr> ").strip()
        except EOFError:
            break
        if not line:
            break
        ok = parse_expression(line, debug=False)  # Debug desactivado
        print("ACEPTA" if ok else "RECHAZA")